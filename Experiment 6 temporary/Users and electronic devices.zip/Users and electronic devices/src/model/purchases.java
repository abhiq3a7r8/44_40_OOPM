package model;

public class purchases {
      Electronic_Device objDev;
      Customer objCust;
      Brand objBrand;
      public void purchases_objDev_objCust(Electronic_Device tempDev, Customer tempCust,Brand tempBrand)
      {
            objDev = tempDev;
            objCust = tempCust;
            objBrand = tempBrand;
      }
    //  public void purchases_objDev_objBrand(Electronic_Device tempDev, Brand tempBrand)
      //{
        //    objDev = tempDev;
          //  objBrand = tempBrand;
      //}

      public void display_ELectronic_Device_Customer()
      {
          System.out.println("Customer_id:"+this.objCust.getCustomer_id()+" Mr."+this.objCust.getCustomer_name()+" (Phone no:"+this.objCust.getPhone_no()+") has purchased a "+this.objBrand.getBrand_Name()+" "+this.objDev.getDevice_Name());
      }

}
