package model;


public class Electronic_Device {
      private int device_Id;
      private String device_Name;
      private String device_Brand;
      private String device_OS;
      private int device_Price;
      //SETTERS
      public void setDevice_Id(){
            this.device_Id=device_Id;
      }
      public void setDevice_Name(String device_Name){
            this.device_Name=device_Name;
      }


      public void setDevice_Brand(String device_Brand) {
            this.device_Brand=device_Brand;
      }

      public void setDevice_OS(String device_OS) {
            this.device_OS =device_OS;
      }

      public void setDevice_Price(int device_Price) {
            this.device_Price =device_Price;
      }
      //GETTERS
      public int getDevice_Id(){
            return this.device_Id;
      }
      public String getDevice_Name(){
            return this.device_Name;
      }
      public String getDevice_Brand(){
            return this.device_Brand;
      }
      public String getDevice_OS(){
            return this.device_OS;
      }
      public int getDevice_Price(){
            return this.device_Price;
      }


}
