package model;

public class Brand {
    private String Brand_Name;

    public void setBrand_Name(String Name)
    {
        this.Brand_Name=Name;
    }
    public String getBrand_Name(){
        return(this.Brand_Name);
    }
}
