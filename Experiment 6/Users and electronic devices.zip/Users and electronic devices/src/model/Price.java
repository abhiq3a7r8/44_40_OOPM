package model;

public class Price {
}
