package Model;

public interface Customer_dsc {
     void addToCart(String product);
     void removeFromCart(String product);
     void viewCart();
}