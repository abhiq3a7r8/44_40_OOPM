package Model;

public interface Electronic_Device_dsc {
    void turnOn();
    void turnOff();
    boolean isTurnedOn();
    void setTimer(int minutes);
}
